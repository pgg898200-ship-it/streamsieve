---
title: PathProbe DAG
emoji: ⏱️
colorFrom: green
colorTo: gray
sdk: static
app_file: index.html
license: mit
tags:
- critical-path
- workflow-optimization
- dask
- agent-workflows
short_description: Find the tool calls that can actually shorten a workflow
---
# PathProbe DAG

**Which tool call would shorten a parallel workflow?** Give PathProbe a task graph, a duration for each task, and a proposed change to one duration. It predicts when the last task would finish with those same dependencies. Use it after collecting a workflow trace and before deciding which call to optimize.

In the demo, shorten Search from 80 to 30 ms. The workflow finishes at 80 ms instead of 120 ms. Lookup takes 40 ms and now determines when Compose can start. Try a different duration or open your own graph locally. The browser accepts up to 512 tasks and 4,096 dependencies. The Python and C++ libraries handle larger graphs.

![Before and after timelines. Cutting search from 80 to 30 ms moves workflow completion from 120 to 80 ms because lookup takes 40 ms.](art/parallel-finish.svg)

[Source, algorithms and reproducible benchmarks](https://github.com/pgg898200-ship-it/causalsieve/tree/pathprobe-dag/tools/pathprobe) · [C++17 header](https://raw.githubusercontent.com/pgg898200-ship-it/causalsieve/pathprobe-dag/tools/pathprobe/native/pathprobe.hpp) · [Sample workflow JSON](https://raw.githubusercontent.com/pgg898200-ship-it/causalsieve/pathprobe-dag/tools/pathprobe/examples/run.json) · [Measured 472-task workflow](https://raw.githubusercontent.com/pgg898200-ship-it/causalsieve/pathprobe-dag/tools/pathprobe/bench/data/montage.json)

## Install the Python tool

Python 3.10+; no runtime dependencies. This wheel is also available from the Files tab.

```sh
python -m pip install 'https://huggingface.co/spaces/pgg-engineering/pathprobe-dag/resolve/main/downloads/pathprobe_dag-0.1.0-py3-none-any.whl#sha256=d1d0c8e4138abb03fb2723ac731b2869739cbf706a566d803f14e1b01f4af462'
```

```python
from pathprobe import DurationIndex
run = DurationIndex({"plan":10,"search":80,"lookup":40,"compose":30},
                    [("plan","search"),("plan","lookup"),("search","compose"),("lookup","compose")])
print(run.predict("search", 30))  # 80 ms, from a baseline of 120 ms
```

## Can a slower tool still meet our deadline?

Across twelve archived public Python SDK CI runs, setting the Python 3.10 test to 289 seconds would meet an illustrative five-minute modeled job-graph budget on nine of the runs. At 290 seconds only six would qualify. A parallel job prevented two runs from ever meeting the modeled budget by changing the 3.10 test alone. These are historical workflow records. The observed wall clock also includes between-job waiting.

```sh
curl -fsSL 'https://raw.githubusercontent.com/pgg898200-ship-it/causalsieve/pathprobe-dag/tools/pathprobe/examples/actions/python-sdk-ci.jsonl' -o ci.jsonl
pathprobe fleet ci.jsonl 'test (Python 3.10)' --duration 289 --required 9
```

[Original CI runs, workflow revisions, and data method](https://github.com/pgg898200-ship-it/causalsieve/tree/pathprobe-dag/tools/pathprobe/examples/actions) · [Capture a fresh Dask workflow](https://raw.githubusercontent.com/pgg898200-ship-it/causalsieve/pathprobe-dag/tools/pathprobe/examples/dask_capture.py)

## Performance and scope

The C++17 index built and answered 1,000,002 independent edits in 80.85 ms on synthetic serial diamonds; a separately implemented eager heap took 145.71 ms. On parallel chains the heap won, 88.44 ms versus 92.58 ms. In the recorded Montage graph, all 472 edits took 18.06 µs including construction; lazy critical-path caching took 21.75 µs and full replay took 948.02 µs. For one edit full replay won each of the four small comparisons. These numbers measure in-process calculations. Each edit holds the topology and other task durations fixed. See the [raw trials](https://github.com/pgg898200-ship-it/causalsieve/tree/pathprobe-dag/tools/pathprobe/bench) for platform, memory, losing cases, and reproduction commands.

The examples and releases are maintained by PGG Engineering. The WfCommons fixtures carry their own terms in the GitHub repository.
