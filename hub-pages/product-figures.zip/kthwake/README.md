---
title: KthWake · Sliding-window threshold scheduler
emoji: ⏱️
colorFrom: yellow
colorTo: green
license: apache-2.0
tags:
  - cpp
  - stream-processing
  - time-series
  - multi-agent
sdk: static
app_file: index.html
short_description: Turn rolling event counts into callbacks and idle deadlines
---

# KthWake · Sliding-window threshold scheduler

Wake a waiting task when three tool results finish in 20 ms. KthWake sits between an ordered stream of completions and a scheduler. Feed it a timestamp and an arrival count. It returns the IDs and new states of rules that changed. The scheduler can set one timer for the next expiry, even when no more results arrive.

## Replay a deadline

The timeline starts with two completions at 0 ms and one at 5 ms. The third completion turns rule 0 on. Choose **Next callback** to watch it turn off at 20 ms, when the first two completions leave the window.

![A three-in-20-ms rule turns on at 5 ms. It turns off at 20 ms on an idle stream, or at 25 ms if two more results arrive at 20 ms.](./deadline-arrivals.svg)

To try the second run, enter `0, 0, 5, 20, 20` under **Completion times (ms)** and choose **Apply trace**. Arrivals and expiries at the same timestamp count together. At 20 ms, the first pair expires and the new pair arrives. Three completions still qualify, so the rule stays on. The next callback turns it off at 25 ms.

The browser timeline runs in JavaScript. Both traces above also ran against the released C++17 implementation. The Python binding and JSONL CLI use the native index.

## Install the Python binding

Build the binding with CPython, a C++17 compiler, wheel and setuptools.

```sh
python -m pip install --no-build-isolation 'git+https://github.com/pgg898200-ship-it/chronosieve.git@7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f#subdirectory=companions/kthwake'
```

```python
from kthwake import Index
ix = Index([(3, 20)])
assert ix.step(100, 2) == []
assert ix.step(105, 1) == [(0, True)]
assert ix.next_expiry() == 120
assert ix.step(120) == [(0, False)]
```

The [release downloads](https://github.com/pgg898200-ship-it/chronosieve/tree/f6df7cdb54362fea22003a814ac83fcc7b179a8f/companions/kthwake/downloads/v0.1.0) include the source archive, header, CPython 3.12 Linux x86-64 wheel, native Linux x86-64 CLI and benchmark results. The file named `SHA256SUMS` lists the digest for each download.

## Benchmarks and contributions

The runnable release includes recorded arrivals from Mooncake and an Azure code-serving holdout, with three modeled policy registries per trace. It also includes million-subscriber synthetic cases, a timestamp-aware correctness oracle and competing native implementations. Evaluations distinguish observation-time snapshots from every timer-driven crossing. On the Azure individual-rate workload, KthWake delivered 330,890 timestamped transitions in 37.1 ms. The fastest of three native heap alternatives took 75.0 ms. The heap won the other two Azure timer workloads.

[Performance evidence](https://github.com/pgg898200-ship-it/chronosieve/blob/7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f/companions/kthwake/EVIDENCE.md) · [Source files](https://github.com/pgg898200-ship-it/chronosieve/tree/7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f/companions/kthwake) · [Independent benchmark instructions](https://github.com/pgg898200-ship-it/chronosieve/blob/7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f/companions/kthwake/REPRODUCE.md) · [Community](https://huggingface.co/spaces/pgg-engineering/kthwake/discussions)
