---
title: RankFence
emoji: 🏁
license: mit
sdk: static
app_file: index.html
short_description: Stop fetching search pages once the top results are settled
tags:
  - information-retrieval
  - reciprocal-rank-fusion
  - hybrid-search
  - rag
  - python
colorFrom: gray
colorTo: gray
thumbnail: https://huggingface.co/spaces/pgg-engineering/rankfence/resolve/main/art/share.png
---

# Stop fetching search pages once the winners are settled

RankFence sits between paged lexical or vector search and the reranker. Give the Python coordinator a ranked cursor per source and the requested top k. It returns the exact ordered IDs under reciprocal rank fusion. If shards have disjoint document IDs, pass a shard map so it can close losing cursors early.

![RankFence. Use a shard map to stop rank fusion once the top k is settled. Three shard streams meet a vertical cutoff. Pages beyond it remain unread.](https://huggingface.co/spaces/pgg-engineering/rankfence/resolve/main/art/share.png)

[Try the shard workbench](https://pgg-engineering-rankfence.static.hf.space/workbench.html) · [Replay the benchmark](https://pgg-engineering-rankfence.static.hf.space/) · [Read the Python source](https://github.com/pgg898200-ship-it/streamsieve/tree/9107326cf0993e842c281d412cb276e83eb1c6a4)

## Try one query

Install the pure Python wheel with Python 3.10 or newer.

```sh
python -m pip install https://huggingface.co/spaces/pgg-engineering/rankfence/resolve/main/rankfence-0.1.0-py3-none-any.whl
```

```python
from rankfence.partition import PartitionFence

f = PartitionFence(["west", "west", "east", "east"], k=1)
for source, ids in enumerate([
    ["west/a", "west/b"], ["west/a", "west/c"],
    ["east/d", "east/e"], ["east/e", "east/d"],
]):
    f.push(source, ids)
assert f.ordered() == ("west/a",)
assert f.done == (False, False, False, False)
```

All four streams remain open when the winner becomes certain. The rank order inside each cursor must stay fixed. Declare a group boundary only when the application guarantees that IDs cannot occur across it. Use flat fusion when overlap is unknown.

On 100 historical TREC topics partitioned into eight simulated shards, RankFence consumed 78,956 of 400,000 ranked IDs and matched every exhaustive top five. A full-window request can be faster for cheap producers. [Measurements, assumptions and competing methods](https://pgg-engineering-rankfence.static.hf.space/benchmarks.html)

[Agent integration guide](https://pgg-engineering-rankfence.static.hf.space/llms.txt) · [Local MCP server](https://github.com/pgg898200-ship-it/streamsieve/blob/9107326cf0993e842c281d412cb276e83eb1c6a4/rankfence/mcp.py) · [Release checksums](https://huggingface.co/spaces/pgg-engineering/rankfence/resolve/main/SHA256SUMS)

## Replay a query with an MCP client

Connect a Streamable HTTP MCP client to `https://rankfence-tools-pgg.tancurl3.chatgpt.site/rpc` and call `rankfence_analyze` with complete ranked lists. The hosted tool reports the winning IDs, how many entries a paged replay read, and whether the order matched exhaustive fusion. The following request settles on `invoice` after 4 of 8 IDs. Omit `source_groups` and the same winner takes all 8.

```json
{"rankings":[["invoice","receipt"],["invoice","receipt"],["guide","manual"],["manual","guide"]],"source_groups":["billing","billing","docs","docs"],"k":1,"page_size":1}
```

Use the local workbench or stdio server to keep document IDs on your machine. [Hosted tool source and input limits](https://github.com/pgg898200-ship-it/streamsieve/tree/rankfence-mcp-0.1.0/remote-mcp)
