---
title: SinceKit · Batched state sync
emoji: 🧭
sdk: static
license: mit
tags:
  - cpp
  - multi-agent
  - simulation
  - change-data-capture
  - state-synchronization
app_file: index.html
short_description: Build one change list for readers at different revisions
colorFrom: gray
colorTo: gray
thumbnail: https://huggingface.co/spaces/pgg-engineering/sincekit/resolve/main/art/share.png
---

# SinceKit

Prepare one exact state delta for thousands of readers at different checkpoints. Each reader takes a prefix of the same array. Two C++17 headers, no third-party dependencies.

![SinceKit. Prepare one changed-key array for readers at different revisions. A single array of changed keys serves three readers. Each reader takes a different prefix.](https://huggingface.co/spaces/pgg-engineering/sincekit/resolve/main/art/share.png)

Use this inside a simulation server, agent blackboard, or fleet monitor when each reader needs the **latest state of the keys that changed**. An agent that slept through a million updates to one key can catch up on that key in one row. Deletes survive as tombstones, and readers keep a single 64-bit cursor.

On a held-out synthetic burst workload with 2,048 readers, the native planner took **17.04 µs**, versus **31.23 µs** for the fastest of three alternative shared-plan implementations. In a replay of observed agent traffic the best alternatives were close, and a sorted sweep won at 2,048 simulated readers. [Workloads, losing cases and raw timings](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/docs/performance.md)

## Try it

Clone this Space and run the example with a C++17 compiler and Make.

```sh
git clone --depth 1 https://huggingface.co/spaces/pgg-engineering/sincekit
cd sincekit
make demo
```

The example writes slot 7, writes slot 3, updates slot 7 and erases slot 3. Three readers last saw revisions 0, 2, and 4. The CLI prints one JSON line.

```json
{"revision":"4","rows":[[3,"4",true],[7,"3",false]],"prefix_lengths":[2,2,0]}
```

Each row contains a slot ID, its last revision and a deletion flag. Both lagging readers receive rows 0 and 1. The current reader receives zero rows. Decimal strings preserve 64-bit revisions in JavaScript. Feed a custom trace into `build/sincekit CAPACITY` with one `touch ID`, `erase ID`, `plan CURSOR ...` or `revision` command per line.

[Replay the three readers in the browser](https://pgg-engineering-sincekit.static.hf.space/index.html) · [Read the workload selection guide](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/llms.txt) · [See measurements and reproduction commands](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/docs/performance.md)

## Embed in a tick loop

Copy `include/sincekit.h` and `include/sincekit_batch.h` into your include path and distribute the accompanying MIT notice. Use one Index per dense slot space and world lifetime.

```cpp
#include "sincekit_batch.h"

sincekit::Index changes(1'000'000);
changes.touch(14);             // first put the application's payload in slot 14
changes.touch(42);
changes.erase(14);

auto batch = sincekit::since_many(changes, {0, 1, 3});
// batch.rows is [erase 14 @ 3, touch 42 @ 2].
// batch.prefix_lengths is [2, 2, 0].
```

For one consumer, `changes.since(cursor, callback)` visits changed slots in descending revision order without allocating. Its callback receives `(id, revision, deleted)`. It returns the revision covered. A completed batch owns its row metadata. If the writer will resume before delivery, copy the corresponding payloads under the same synchronization. Publish the cursor only after the whole prefix has been applied. The [replication example](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/examples/replicate.cpp) handles a lagging consumer, retry, and world restart.

## Why a prefix is enough

A key's latest revision is unique and each update moves that key to the front of the index. For a cursor C, its delta is all latest revisions greater than C. In descending order these make one prefix. The oldest cursor in a batch determines the longest prefix. All newer readers share its rows and need only a length.

| Operation | Cost |
|---|---|
| Update or delete a dense slot | Constant-time list maintenance, no allocation |
| Pull K changed slots for one cursor | O(K + 1) |
| Store the index | O(slot capacity), independent of update count and reader lag |
| Prepare one batch for R readers and U distinct changed slots | O(U + R) for contiguous revisions and selected dense rank windows, O(U + R log(U + 1)) otherwise |
| Store the shared result | O(U + R) |
| Deliver over independent sockets or apply on every replica | Proportional to the sum of the readers' prefix lengths and payload sizes |

A contiguous revision window gives prefix lengths by subtraction. For dense windows with enough readers, the batch planner builds a small bitmap of revisions and counts set bits to answer each prefix query. Sparse windows use bounded buckets of revision ranges when enough readers justify an index, with a short search inside the matching bucket. The benchmark compares these paths with independently implemented shared-plan alternatives.

## Choosing a native index

`Index` moves changed slots to the head of a list. It is a good candidate for repeated writes to a hot subset or short output-sensitive pulls. The optional `sincekit::CompactIndex` in [sincekit_compact.h](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/include/sincekit_compact.h) trades occasional O(capacity) compactions for contiguous journal traversal. It exposes the same C++ methods and works with `since_many`. Its writes are amortized O(1) and a poll scans at most two journal generations. The benchmarks include a million-slot mixed replay where the linked index loses. Choose using measured tick latency and your tolerance for compaction pauses.

Both native indexes use approximately 16 bytes per configured slot plus a deletion bit on the tested ABI, excluding vector and allocator overhead. Applications that have a compatible newest-first source can also call the templated batch planner with that source.

## Data and concurrency contract

* IDs range from zero to capacity minus one. Capacity is fixed. Map sparse external IDs to stable local slots. Reuse a slot only if replacing its entity is an acceptable latest-state operation.
* Every successful touch or erase advances the revision, including repeated erases. Revision zero means the beginning of this index. A future cursor throws. A cursor from a different index can have a numerically valid value, so pair it with an application-owned world or session ID.
* Writers must exclude all readers and other writers. Between writes, immutable reads can overlap. A callback may read the same index recursively. Mutation from its callback throws. If a callback fails, retry from the original cursor and make applying the prefix idempotent.
* The index retains the latest marker of every touched slot, including deletion, for its lifetime. It stores no payloads, wall-clock history, or durable log. Applications needing every intermediate action, multi-writer reconciliation, or crash recovery should use an appropriate event store or replication system.
* Share a batch only among consumers allowed to see the same keyspace. A prefix is a revision boundary. Partition by visibility before planning when consumers have different access.

Run `make check` for the native, command-protocol, and replication checks. Run `make benchmark` for the synthetic baselines. Python integration, a timestamped trace replay, and individual compiler commands are documented alongside their sources.

## License

SinceKit code and original documentation use the [MIT license](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/LICENSE). The derived FreeInference trace keeps its original CC BY 4.0 license. See the [trace attribution and transformation](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/trace/README.md).

## Python

Install the native extension from this checkout with `python3 -m pip install --no-build-isolation --no-deps ./python` in an environment with setuptools and a compiler. The [Python guide](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/python/README.md) shows atomic batch writes and how to consume reader prefixes without copying them.

```python
from sincekit import Index

world = Index(10_000)
world.write_many([(42, False), (9, False), (42, True)])
batch = world.since_many([0, 2, 3])
assert batch.prefix_lengths == (2, 1, 0)
```

[Clone and evaluate SinceKit](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/docs/quickstart.md) · [Run the SimPy warehouse integration](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/integrations/simpy/README.md) · [Choose between SinceKit and other synchronization models](https://huggingface.co/spaces/pgg-engineering/sincekit/blob/main/docs/fit.md)
