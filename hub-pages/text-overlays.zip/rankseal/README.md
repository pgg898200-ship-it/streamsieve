---
title: RankSeal · Early stopping for hybrid search
emoji: 🔎
colorFrom: green
colorTo: gray
sdk: static
app_file: index.html
license: mit
short_description: Certify the ordered top k while retrievers return pages
tags:
- information-retrieval
- hybrid-search
- reciprocal-rank-fusion
- multi-agent
- benchmark
---

# RankSeal

RankSeal combines paged search results using weighted reciprocal rank fusion (RRF). Give it the ranked document IDs each retriever has returned so far. It certifies the exact top k in order as soon as unseen pages can no longer change the answer. For an unfinished query, its auditor can show two possible ways the retrievers could finish that would produce different answers.

On 623 queries from published BM25 and dense retrievers, parallel five-ID pages found the exact winner with **2,214 of 12,460 pages**. A hindsight analysis that tries every potentially better pair of source depths establishes a minimum of **2,212** under the same paging contract. With one in-flight request and the lexical retriever first, the serial reader hit the proven minimum on **all 623 queries**. A reference implementation of the standard no-random-access algorithm also took 2,214. This is a measurement of retriever pages. Wall-clock latency depends on the search service.

[Audit your own two rankings in the browser](https://pgg-engineering-rankseal.static.hf.space/workbench.html) · [Interactive demo](https://huggingface.co/spaces/pgg-engineering/rankseal) · [Download the complete source, data and benchmarks](https://huggingface.co/spaces/pgg-engineering/rankseal/resolve/main/releases/rankseal-0.1.0.zip) · [Raw results](https://huggingface.co/spaces/pgg-engineering/rankseal/resolve/main/releases/benchmarks.json)

## Try an exact early stop

Python 3.10 or newer. The package has zero runtime dependencies.

```sh
python -m pip install https://huggingface.co/spaces/pgg-engineering/rankseal/resolve/main/releases/rankseal-0.1.0-py3-none-any.whl
python -m rankseal --sources 2 -k 1 <<'EOF'
{"source":0,"ids":["alpha","beta","gamma"]}
{"source":1,"ids":["alpha","delta","epsilon"]}
EOF
```

The CLI returns `{"certified":true,"ids":["alpha"],"pages":2,"ids_read":[3,3]}`. Both sources could still have more pages. The best possible score for any rival is already below alpha’s score. The CLI exits immediately after a certificate. If input ends first, it reports an incomplete result and exits with code 3. A known final page should carry `"final":true`.

## When should I stop fetching more hybrid search results?

Use RankSeal when each extra page requires a remote call, transfers a large payload, or advances an expensive cursor. It is especially useful when agents agree about the first result and the application needs one verified document or tool. The terminal proof covers the IDs and their order. Individual scores can continue to change.

Each source must supply stable, consistently ordered, unique IDs over the configured ranking window. Use the same canonical document IDs across agents. Ranks start at 1, missing IDs contribute zero, weights and the rank constant are positive integers, and score ties resolve by ascending Python string order. A source failure cannot count as exhaustion. When rankings already sit in memory, ordinary accumulation and top-k selection can be faster. Some backends compute an entire ranking on the first request, so stopping later pages there primarily saves transfer and subsequent requests.

```python
import asyncio
from rankseal import Page, fuse_pages

async def retriever(pages):
    for i, ids in enumerate(pages):
        yield Page(ids, final=i == len(pages) - 1)

async def main():
    result = await fuse_pages([
        retriever([["A", "B"], ["C"]]),
        retriever([["A", "D"], ["B"]]),
    ], k=1)
    print(result.ids, result.pages_received)  # ('A',) (1, 1)

asyncio.run(main())
```

Use `max_in_flight=1` to read pages serially in source order, or a larger limit to constrain concurrent requests. The async reader fetches at most one pending page per source and closes its iterators after returning or on error. In-flight network work can still complete. `pages_requested`, `pages_received`, `ids_received`, and `exhausted` are reported separately. Applications that already own the event loop or scheduling policy can call `Fusion.push`, `Fusion.close` and `Fusion.certified` directly. The [Elasticsearch adapter](https://huggingface.co/spaces/pgg-engineering/rankseal/blob/main/docs/elasticsearch.md) uses point-in-time pagination.

## Could another reader stop earlier?

The audit command independently recomputes exact rational bounds. For an unresolved prefix it emits a second completion that changes the answer. In this example, ending both sources now yields `A`; putting `B` next in the second source yields `B`.

```sh
echo '{"prefixes":[["A","B"],[]],"closed":[true,false],"k":1}' | python -m rankseal.audit
```

For a recorded query with two complete rankings, the frontier command returns every minimal combination of page counts that proves the order. It walks the boundary of the grid, taking at most `P+Q+1` prefix checks for sources of `P` and `Q` pages. A hindsight schedule has access to the recorded trace. Live readers learn its contents only as pages arrive.

```sh
echo '{"rankings":[["x","a","b"],["x","c","d"]],"page_size":1,"k":1}' | python -m rankseal.frontier
```

## Measured performance

We replayed the full published top-50 BM25 and BGE runs for all 300 SciFact and 323 NFCorpus queries. Page size was five, with one request per source per parallel round and an exhaustion marker on each final page. Each output was checked against independent full-scan rational RRF. The real-ranking replay also checks page size ten and two values of k, for 2,492 query/settings.

| Dataset and requested output | Pages read / exhaustive | Pages avoided | Hindsight minimum |
| --- | ---: | ---: | ---: |
| SciFact, winner | 752 / 6,000 | 87.47% | 751 |
| NFCorpus, winner | 1,462 / 6,460 | 77.37% | 1,461 |
| SciFact, ordered top 10 | 5,128 / 6,000 | 14.53% | 5,019 |
| NFCorpus, ordered top 10 | 5,660 / 6,460 | 12.38% | 5,582 |

A separate HTTP/1.1 loopback benchmark used 32 fixed queries per dataset, three repetitions, and the same concurrency for both readers. With 2 ms of injected service time per page, median top-1 elapsed time was **2.90 vs 29.83 ms** on SciFact and **5.16 vs 32.61 ms** on NFCorpus. Ordered top-10 medians were mixed (36.08 vs 37.24 ms on SciFact and 32.66 vs 31.28 ms on NFCorpus). With zero injected delay, ordered top-10 was slower on both. Timings were taken on a shared host. This replay includes sockets, pages, fusion, and cleanup. The underlying model and search engine had already produced the rankings.

In a synthetic 256-source, 65,536-entry fan-in test, an agreed top‑10 took 11.50 ms median and read 4,096 entries. Shuffled overlap needed all entries and 494 ms. These are single-process measurements of simulated sources. Results and machine configuration are recorded with each benchmark.

![Share of real queries with a provable ordered answer by pages read](https://huggingface.co/spaces/pgg-engineering/rankseal/resolve/main/docs/page-budget.png)

The experimental serial scheduler gives one source the next request according to the rival still blocking the proof. At top-10 with equal page costs, it matched the hindsight minimum on 620 of 623 queries. The remaining three needed one extra page each. Serial paging can add network round trips. The live API uses concurrent requests. The [scheduling results](https://huggingface.co/spaces/pgg-engineering/rankseal/blob/main/docs/scheduling.json) include cost asymmetries and cases that favor round-robin.

## Reproduce or test a new workload

```sh
git clone https://huggingface.co/spaces/pgg-engineering/rankseal
cd rankseal
python -m unittest discover -s tests
python -m bench.real
python -m bench.verify_frontier
python -m bench.minimum_reads
python -m bench.synthetic --counts-only
python -m bench.loopback
python -m bench.scale
```

The models and query text are unnecessary for replay. To test another workload, retain only ordered canonical IDs from each source, fix its snapshot and scoring window, then run the auditor and frontier on those rankings. You can rename sensitive IDs while preserving lexical tie order. Please include source count, page size, k, ranking depth, exact mismatches, avoided requests and measured latency in any independent reproduction.

[Data provenance and license](https://huggingface.co/spaces/pgg-engineering/rankseal/blob/main/docs/real-data.md) · [Proof and prior art](https://huggingface.co/spaces/pgg-engineering/rankseal/blob/main/docs/algorithm.md) · [Independent benchmark runs](https://github.com/sergiyclas/retrieval-arena) · [Community reproductions and integration reports](https://huggingface.co/spaces/pgg-engineering/rankseal/discussions)
