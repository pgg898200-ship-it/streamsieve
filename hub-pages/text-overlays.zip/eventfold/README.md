---
title: EventFold · SSE compression
emoji: 📡
colorFrom: green
colorTo: blue
sdk: static
app_file: index.html
license: mit
tags:
  - streaming
  - compression
  - server-sent-events
  - sse
  - inference-gateway
short_description: Compare wire bytes and verify exact event reconstruction
---

# EventFold

Place EventFold between an inference server and its gateway. The encoder sends one compressed frame per server-sent event (SSE). The decoder restores the original bytes, including comments, spaces and line endings, before the gateway forwards the event to clients. Both ends of the internal link must support the EventFold format.

[Open the wire inspector](https://pgg-engineering-eventfold.static.hf.space/index.html), paste a captured stream or open a local file, and step through its frames. The inspector compares sample-sized inputs locally. The downloadable codec and CLI handle streaming workloads.

[Source and reproducible benchmarks](https://github.com/pgg898200-ship-it/backfold/tree/ba58afba44f1ec76e050977baf8a277819feab9f/companions/eventfold) · [Download the full source](https://huggingface.co/spaces/pgg-engineering/eventfold/resolve/main/eventfold-source.tar.gz) · [C99 single header](https://huggingface.co/spaces/pgg-engineering/eventfold/resolve/main/eventfold.h) · [Wire format](https://github.com/pgg898200-ship-it/backfold/blob/ba58afba44f1ec76e050977baf8a277819feab9f/companions/eventfold/docs/format.md)

Source archive SHA-256: `dd3b5f1b919bb8f822995e63d80360e7ce7c48d358207ebeb8a4cc0fe09d47f3`. GitHub revision: `ba58afba44f1ec76e050977baf8a277819feab9f`. EventFold is MIT-licensed. Third-party fixtures in the archive carry their own notices.
