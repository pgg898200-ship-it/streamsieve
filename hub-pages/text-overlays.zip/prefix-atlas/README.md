---
title: Prefix Atlas · KV cache sizing
emoji: 📈
colorFrom: blue
colorTo: green
sdk: static
app_file: index.html
short_description: Find the page budget for a target prefix-cache hit rate
tags:
  - llm-serving
  - kv-cache
  - performance
  - trace-replay
  - prefix-caching
---

# Prefix Atlas

Calculate how many KV-cache pages a serial LRU cache needs to reach a target prefix hit rate. Use the planner before choosing a cache budget for an LLM serving engine. [Open the calculator](https://pgg-engineering-prefix-atlas.static.hf.space/index.html), choose one of two measured agent workloads, or load a capacity curve generated from your own trace. The calculator includes the complete capacity breakpoints and works without a backend.

On 1,375 top-level FreeInference requests from May 17, 2026, 8,822 pages are sufficient for an 80% hit rate under this model. The denominator is the number of complete page references. See the code for the cache policy, workloads where a simpler implementation is faster, and a reproducible upstream PrefixSim comparison. Serving latency, concurrency and in-flight cache pins require engine-specific testing.

[Source, CLI, and benchmarks](https://github.com/pgg898200-ship-it/cachepin/tree/main/tools/prefix-atlas) · [Trace attribution](https://github.com/pgg898200-ship-it/cachepin/blob/main/tools/prefix-atlas/trace_sources.md)

## Bring a request trace

With Python 3.9+ and a C++17 compiler, install the CLI and turn a Mooncake-format request log into a capacity curve. Set the block size to the number of tokens per block in your trace. Open the resulting CSV in the calculator.

```sh
python -m pip install 'git+https://github.com/pgg898200-ship-it/cachepin.git#subdirectory=tools/prefix-atlas'
prefix-atlas requests.jsonl --block-size 16 --curve > capacity.csv
```
