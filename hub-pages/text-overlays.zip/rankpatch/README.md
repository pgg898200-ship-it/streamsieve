---
title: RankPatch · Live rank fusion
emoji: 📊
colorFrom: blue
colorTo: green
sdk: static
app_file: index.html
license: apache-2.0
short_description: Update the combined top k when one search ranking changes
tags:
- information-retrieval
- rank-fusion
- streaming
- cpp
- hybrid-search
---
# RankPatch

Place RankPatch after your retrievers and before the client that reads a combined ranking. Each search worker sends a revision and a ranked list of document IDs. Replacing or withdrawing one list updates the exact top k under your rank-point table.

[Open the live rank-fusion demo](https://pgg-engineering-rankpatch.static.hf.space/index.html) to edit a retriever’s list, send a revision, or withdraw it. The demo shows which sources contributed each point and exports a runnable C++17 example for the state on screen. It runs locally in your browser using a JavaScript reference implementation.

The native library is a single header with a CPython binding. Across 1,024 simulated sources with low overlap, replacing one 32-item list and reading the top ten measured 742 ns median versus 2,003 ns for an indexed heap. The heap was faster on the progressive SciFact workload. These are native kernel measurements on one host.

[Install RankPatch](https://github.com/pgg898200-ship-it/rankpatch) · [Compare all workloads](https://github.com/pgg898200-ship-it/rankpatch/tree/main/bench) · [Reproduce the SciFact experiment](https://github.com/pgg898200-ship-it/rankpatch/tree/main/replay)
