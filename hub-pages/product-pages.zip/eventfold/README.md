---
title: EventFold
emoji: 📡
colorFrom: green
colorTo: blue
sdk: static
app_file: index.html
license: mit
tags:
  - streaming
  - compression
  - server-sent-events
short_description: Compress streaming LLM events between a server and gateway.
---

# EventFold

EventFold compresses Server-Sent Events (SSE) one event at a time on the link between an inference server and a gateway. The gateway decodes each event and forwards the original SSE bytes to clients. Both ends of the internal link must support the EventFold wire format.

[Open the wire inspector](https://huggingface.co/spaces/pgg-engineering/eventfold). Paste a short SSE capture or open a local file to compare frame sizes and verify that decoding recovers the input. The native C99 header and Python CLI handle streaming workloads.

[Source and reproducible benchmarks](https://github.com/pgg898200-ship-it/backfold/tree/ba58afba44f1ec76e050977baf8a277819feab9f/companions/eventfold) · [Download the full source](https://huggingface.co/spaces/pgg-engineering/eventfold/resolve/main/eventfold-source.tar.gz) · [C99 single header](https://huggingface.co/spaces/pgg-engineering/eventfold/resolve/main/eventfold.h) · [Wire format](https://github.com/pgg898200-ship-it/backfold/blob/ba58afba44f1ec76e050977baf8a277819feab9f/companions/eventfold/docs/format.md)

Source archive SHA-256: `dd3b5f1b919bb8f822995e63d80360e7ce7c48d358207ebeb8a4cc0fe09d47f3`. GitHub revision: `ba58afba44f1ec76e050977baf8a277819feab9f`. EventFold is MIT-licensed. Third-party fixtures in the archive carry their own notices.
