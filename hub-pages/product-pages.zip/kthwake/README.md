---
title: KthWake
emoji: ⏱️
colorFrom: green
colorTo: gray
license: apache-2.0
sdk: static
app_file: index.html
short_description: Wake a scheduler when a rolling count crosses its threshold
tags:
  - stream-processing
  - sliding-window
  - event-time
  - cpp
  - python
  - asyncio
---

# Wake a scheduler when a rolling count crosses its threshold

An agent is waiting for three results in 20 milliseconds. Two arrive at tick 100 and one at 105. The rule turns on at 105. Even if no more results arrive, it turns off at 120.

Put KthWake in the event loop after timestamped arrivals and before subscriber callbacks. Send one ordered stream of integer timestamps and counts. The index returns every subscriber whose rule changed and the next idle deadline. A scheduler can arm one timer for all rules on that stream.

[Step through the timeline](https://pgg-engineering-kthwake.static.hf.space/) · [Download the C++17 header](https://huggingface.co/spaces/pgg-engineering/kthwake/resolve/main/kthwake.hpp) · [Source and asyncio example](https://github.com/pgg898200-ship-it/chronosieve/tree/7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f/companions/kthwake)

## Run the native example

Download the complete source archive, then build the bundled trace with Make and a C++17 compiler.

```sh
curl -fL https://huggingface.co/spaces/pgg-engineering/kthwake/resolve/main/kthwake-0.1.0.tar.gz -o kthwake-0.1.0.tar.gz
tar -xzf kthwake-0.1.0.tar.gz
cd kthwake-0.1.0
make example
```

The CLI emits JSON Lines. In the sample, rule 0 turns on at tick 105 and off at tick 120. To embed the index in Python, install the extracted directory with CPython, setuptools, wheel and a C++17 compiler using `python -m pip install --no-build-isolation .`.

The browser illustrates one rule in JavaScript. On a native replay of a held-out Azure trace, 4,096 modeled individual-rate rules produced 330,890 transitions in 37.1 ms. The fastest tested heap took 75.0 ms and won the other two Azure workloads. [Full comparison](https://github.com/pgg898200-ship-it/chronosieve/tree/7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f/companions/kthwake/EVIDENCE.md) · [Reproduce the benchmark](https://github.com/pgg898200-ship-it/chronosieve/tree/7cca93890a5bfa1e120f6aaabda8d1b8d7957b1f/companions/kthwake/REPRODUCE.md) · [Download checksums](https://huggingface.co/spaces/pgg-engineering/kthwake/resolve/main/SHA256SUMS)
