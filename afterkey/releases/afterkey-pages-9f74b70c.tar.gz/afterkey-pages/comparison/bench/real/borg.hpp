#ifndef TAILSTATE_BENCH_BORG_HPP
#define TAILSTATE_BENCH_BORG_HPP
#include "tailstate.h"
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <stdexcept>
#include <utility>
#include <vector>

struct Event {
    uint64_t time, value;
    uint32_t key;
    int deleted;
};
using Rows = std::vector<ts_change>;
struct Poll { size_t end; Rows expected; };
using Clock = std::chrono::steady_clock;

static void check(bool ok) { if (!ok) throw std::runtime_error("trace replay mismatch"); }

static std::vector<Poll> windows(const std::vector<Event> &events, uint64_t interval)
{
    std::vector<Poll> polls;
    size_t i = 0;
    /* The initial poll consumes the timestamp-zero snapshot. Include empty
     * periods and one final partial period. Ties retain their source-file order. */
    for (uint64_t deadline = 0; i < events.size(); deadline += interval) {
        std::map<uint32_t, ts_change> latest;
        while (i < events.size() && events[i].time <= deadline) {
            const auto &e = events[i++];
            latest[e.key] = {i, e.value, e.key, e.deleted};
        }
        Rows expected;
        for (const auto &kv : latest) expected.push_back(kv.second);
        std::sort(expected.begin(), expected.end(), [](const auto &a, const auto &b) {
            return a.seq < b.seq;
        });
        polls.push_back({i, std::move(expected)});
    }
    return polls;
}

static std::vector<Event> input(uint32_t &keys)
{
    size_t count;
    check(bool(std::cin >> keys >> count));
    std::vector<Event> events(count);
    for (auto &e : events)
        check(bool(std::cin >> e.time >> e.key >> e.value >> e.deleted) && e.key < keys);
    check(!events.empty());
    return events;
}

static void verify(const Rows &out, const Rows &expected)
{
    check(out.size() == expected.size());
    for (size_t i = 0; i < out.size(); ++i) {
        const auto &a = out[i], &b = expected[i];
        check(a.seq == b.seq && a.value == b.value && a.key == b.key && a.deleted == b.deleted);
    }
}
#endif
