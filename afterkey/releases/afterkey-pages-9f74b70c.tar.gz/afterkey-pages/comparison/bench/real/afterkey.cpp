/* Reads the exact same normalized Google Borg trace as replay.cpp. */
#include "borg.hpp"
#include "afterkey.hpp"
#include "afterkey_journal.hpp"
#include "paged_afterkey.hpp"
#include "paged_afterkey_journal.hpp"
#include <array>
#include <limits>
#include <memory>
#include <optional>
#include <random>

constexpr size_t unlimited = std::numeric_limits<size_t>::max();
struct Cursor { uint64_t seq = 0; std::optional<uint32_t> key; };
struct Measurement { double write_ms, read_ms; size_t calls; };

struct Tail {
    std::unique_ptr<ts_store, decltype(&ts_destroy)> store;
    Tail(uint32_t n, bool indexed):
        store(indexed ? ts_create_indexed(n) : ts_create(n), ts_destroy) { check(bool(store)); }
    void write(const Event &e) {
        check((e.deleted ? ts_delete(store.get(), e.key) : ts_put(store.get(), e.key, e.value)) == TS_OK);
    }
    void read(Cursor c, size_t limit, Rows &out) {
        ts_iter it;
        check((c.key ? ts_resume(store.get(), c.seq, *c.key, &it) : ts_begin(store.get(), c.seq, &it)) == TS_OK);
        for (size_t i = 0; i < limit; ++i) {
            ts_change row;
            auto status = ts_next(&it, &row);
            if (status == TS_DONE) return;
            check(status == TS_ROW);
            out.push_back(row);
        }
    }
};

template<typename Impl, bool extended>
struct After {
    Impl store;
    explicit After(uint32_t n): store(n) {}
    void write(const Event &e) {
        if (e.deleted) store.erase(e.key); else store.put(e.key, e.value);
    }
    void read(Cursor c, size_t limit, Rows &out) {
        auto append = [&](uint64_t seq, uint32_t key, const uint64_t *value) {
            out.push_back({seq, value ? *value : 0, key, !value});
        };
        if (limit == unlimited) {
            store.since(c.seq, append);
        } else if constexpr (extended) {
            store.since_page(c.seq, c.key, limit, append);
        } else {
            /* The released API visits every successor. Use it only for the
             * full-poll comparison. Bounded runs use the native page patch. */
            throw std::logic_error("released Afterkey lacks a native page API");
        }
    }
};

template<typename Store>
static Measurement measure(Store &store, const std::vector<Event> &events,
                           const std::vector<Poll> &polls, uint32_t keys, size_t limit)
{
    size_t i = 0;
    Cursor c;
    Rows rows;
    rows.reserve(keys);
    Measurement result{};
    for (const auto &p : polls) {
        auto start = Clock::now();
        while (i < p.end) store.write(events[i++]);
        result.write_ms += std::chrono::duration<double, std::milli>(Clock::now() - start).count();
        rows.clear();
        start = Clock::now();
        do {
            const size_t before = rows.size();
            store.read(c, limit, rows);
            ++result.calls;
            if (rows.size() > before) {
                const auto &last = rows.back();
                c = {last.seq, last.key};
            }
            if (rows.size() - before < limit) break;
        } while (c.seq < p.end);
        result.read_ms += std::chrono::duration<double, std::milli>(Clock::now() - start).count();
        verify(rows, p.expected);
    }
    return result;
}

int main()
{
    uint32_t keys;
    const auto events = input(keys);
    constexpr size_t repeats = 11;
    std::mt19937 rng(20261122);
    const char *names[] = {"tail_compact", "tail_indexed", "after_index", "after_journal",
                           "candidate_index", "candidate_journal", "candidate_journal_summary"};
    std::cout << "method,poll_hours,page_limit,calls,rows,write_median_ms,read_median_ms,total_median_ms\n";
    for (uint64_t hours : {1, 24}) {
        const auto polls = windows(events, hours * 3600 * UINT64_C(1000000));
        size_t count = 0;
        for (const auto &poll : polls) count += poll.expected.size();
        for (size_t limit : {unlimited, size_t{16}}) {
            std::vector<unsigned> methods = limit == unlimited ? std::vector<unsigned>{0,1,2,3,4,5,6}
                                                               : std::vector<unsigned>{0,1,4,5,6};
            std::array<std::array<double, repeats>, 7> writes{}, reads{}, totals{};
            size_t calls = 0;
            for (size_t r = 0; r < repeats; ++r) {
                std::shuffle(methods.begin(), methods.end(), rng);
                for (auto m : methods) {
                    auto run = [&](auto &&s) { return measure(s, events, polls, keys, limit); };
                    Measurement measured;
                    switch (m) {
                    case 0: case 1: measured = run(Tail(keys, m == 1)); break;
                    case 2: measured = run(After<afterkey::Index<uint64_t>, false>(keys)); break;
                    case 3: measured = run(After<afterkey::Journal<uint64_t>, false>(keys)); break;
                    case 4: measured = run(After<paged_afterkey::Index<uint64_t>, true>(keys)); break;
                    case 5: measured = run(After<paged_afterkey::Journal<uint64_t>, true>(keys)); break;
                    case 6: measured = run(After<paged_afterkey::Journal<uint64_t, true>, true>(keys)); break;
                    default: throw std::logic_error("unknown method");
                    }
                    if (!calls) calls = measured.calls;
                    check(calls == measured.calls);
                    writes[m][r] = measured.write_ms;
                    reads[m][r] = measured.read_ms;
                    totals[m][r] = measured.write_ms + measured.read_ms;
                }
            }
            std::sort(methods.begin(), methods.end());
            for (auto m : methods) {
                auto median = [](auto sample) {
                    std::sort(sample.begin(), sample.end());
                    return sample[sample.size() / 2];
                };
                std::cout << names[m] << ',' << hours << ',' << (limit == unlimited ? 0 : limit)
                          << ',' << calls << ',' << count << ',' << median(writes[m]) << ','
                          << median(reads[m]) << ',' << median(totals[m]) << '\n';
            }
        }
    }
}
