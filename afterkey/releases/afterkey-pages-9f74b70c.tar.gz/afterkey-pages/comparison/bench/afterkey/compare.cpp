// Independent sibling comparison. prepare.py stages two pinned Afterkey revisions.
#include "tailstate.h"
#include "afterkey.hpp"
#include "afterkey_journal.hpp"
#include "paged_afterkey.hpp"
#include "paged_afterkey_journal.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <random>
#include <stdexcept>
#include <vector>

using Clock = std::chrono::steady_clock;
constexpr uint32_t capacity = 65536, rounds = 7, requests = 32;
constexpr size_t unlimited = std::numeric_limits<size_t>::max();
static bool measure_alloc;
static size_t requested;
void* operator new(size_t size) {
    auto p = std::malloc(size ? size : 1);
    if (!p) throw std::bad_alloc();
    if (measure_alloc) requested += size;
    return p;
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, size_t) noexcept { std::free(p); }
void* operator new[](size_t n) { return ::operator new(n); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete[](void* p, size_t) noexcept { std::free(p); }

using Row = ts_change;
struct Query { uint64_t seq; uint32_t key; size_t limit; };
struct Hash { uint64_t value=1, rows=0; };
static void require(bool ok) { if (!ok) throw std::runtime_error("benchmark mismatch"); }
static uint64_t nanos(Clock::time_point start) {
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count());
}
static uint64_t median(std::vector<uint64_t> v) {
    std::sort(v.begin(),v.end()); return v[v.size()/2];
}
static void digest(Hash& h,const Row& r) {
    h.value = (h.value ^ r.value ^ r.seq) * UINT64_C(1099511628211) + r.key + (unsigned)r.deleted;
    ++h.rows;
}

struct Tail {
    std::unique_ptr<ts_store,decltype(&ts_destroy)> p;
    explicit Tail(bool indexed):p(indexed?ts_create_indexed(capacity):ts_create(capacity),ts_destroy) { require(bool(p)); }
    void write(const Row& r) { require((r.deleted?ts_delete(p.get(),r.key):ts_put(p.get(),r.key,r.value))==TS_OK); }
    template<class F> void read(Query q,bool hint,F f) const {
        ts_iter it;
        require((hint?ts_resume(p.get(),q.seq,q.key,&it):ts_begin(p.get(),q.seq,&it))==TS_OK);
        Row row;
        int status = TS_ROW;
        for(size_t i=0;i<q.limit && (status=ts_next(&it,&row))==TS_ROW;++i) f(row);
        require(status==TS_ROW || status==TS_DONE);
    }
};

struct Stop {};
template<class Impl, bool modified=false>
struct After {
    Impl p{capacity};
    void write(const Row& r) { if(r.deleted)p.erase(r.key);else p.put(r.key,r.value); }
    template<class F> void read(Query q,bool hint,F f) const {
        size_t left=q.limit;
        auto visit=[&](uint64_t seq,uint32_t key,const uint64_t* value) {
            f(Row{seq,value?*value:0,key,!value});
        };
        if constexpr (modified) {
            if (q.limit==unlimited) { p.since(q.seq,visit); return; }
            std::optional<uint32_t> anchor;
            if (hint) anchor=q.key;
            (void)p.since_page(q.seq,anchor,q.limit,visit);
        } else {
            if (q.limit==unlimited) { p.since(q.seq,visit); return; }
            try {
                p.since(q.seq,[&](auto seq,auto key,auto value) {
                    visit(seq,key,value);
                    if (--left==0) throw Stop{};
                });
            } catch (Stop&) {}
        }
    }
};

using AI=After<afterkey::Index<uint64_t>>;
using AJ=After<afterkey::Journal<uint64_t>>;
using PI=After<paged_afterkey::Index<uint64_t>,true>;
using PJ=After<paged_afterkey::Journal<uint64_t>,true>;
using PS=After<paged_afterkey::Journal<uint64_t,true>,true>;
enum Method { TC,TI,AI0,AJ0,PI0,PJ0,PS0,COUNT };
static const char* const labels[]={"tail-compact","tail-indexed","after-index","after-journal","after-index-page","after-journal-page","after-journal-sparse"};
static const char* const groups[]={"valid-anchor-page","overwritten-anchor-page","multirate-full","uniform-start-full","cluster-rewrite-page"};

struct Work {
    std::vector<Row> trace,current;
    std::array<std::vector<Query>,5> queries;
    std::array<std::vector<std::vector<Row>>,5> oracle;
};

static Work workload(unsigned phase) {
    Work w;
    std::mt19937 rng(304901);
    std::vector<uint32_t> perm(capacity);
    std::iota(perm.begin(),perm.end(),0u);
    std::shuffle(perm.begin(),perm.end(),rng);
    auto append=[&](uint32_t k,bool deleted) {
        uint64_t seq=w.trace.size()+1;
        w.trace.push_back({seq,deleted?0:seq*9u,k,deleted});
    };
    for(auto k:perm) append(k,false);
    for(uint32_t i=0;i<capacity;i+=4) append(perm[i],i%12==0);
    if(phase) {
        for (uint32_t i=0;i<capacity*3;++i) {
            uint32_t hot_idx=i%1024==0?32+i/1024:rng()%32;
            append(perm[hot_idx],(rng()&15u)==0);
        }
    }
    if(phase==2) {
        // Retire the middle quarter of the initial registration batch in one burst.
        for(uint32_t i=capacity/4;i<capacity/2;++i) append(perm[i],true);
    }
    w.current.resize(capacity);
    for(auto r:w.trace)w.current[r.key]=r;
    std::sort(w.current.begin(),w.current.end(),[](auto a,auto b){return a.seq<b.seq;});
    for(unsigned i=0;i<requests;++i) {
        uint32_t base=4*(capacity/16+rng()%(capacity/8));
        if(phase==2) {
            uint32_t old=capacity/4+4*i+1;
            w.queries[4].push_back({old+1,perm[old],16});
            continue;
        }
        w.queries[0].push_back({base+2,perm[base+1],16});
        w.queries[1].push_back({base+1,perm[base],16});
        w.queries[phase?2:3].push_back({w.trace.size()-(phase?32768:4096)+i,0,unlimited});
    }
    for(unsigned g=0;g<5;++g)for(auto q:w.queries[g]) {
        auto first=std::upper_bound(w.current.begin(),w.current.end(),q.seq,
            [](uint64_t seq,const Row& r){return seq<r.seq;});
        auto take=std::min(q.limit,static_cast<size_t>(w.current.end()-first));
        w.oracle[g].emplace_back(first,first+take);
    }
    return w;
}

struct Samples {
    std::vector<uint64_t> init,write;
    size_t bytes=0;
    std::array<std::array<std::vector<uint64_t>,2>,5> reads;
};
static volatile uint64_t sink;
template<class Store> static void trial(Store& s,const Work& w,Samples& out, bool supports_hint) {
    auto start=Clock::now();
    for(size_t i=0;i<capacity;++i)s.write(w.trace[i]);
    out.init.push_back(nanos(start));
    start=Clock::now();
    for(size_t i=capacity;i<w.trace.size();++i)s.write(w.trace[i]);
    out.write.push_back(nanos(start));
    for(unsigned g=0;g<5;++g)for(unsigned h=0;h<((supports_hint && (g<2 || g==4))?2u:1u);++h) {
        for(size_t i=0;i<w.queries[g].size();++i) {
            const auto& expected=w.oracle[g][i];
            size_t j=0;
            s.read(w.queries[g][i],h,[&](const Row& r) {
                require(j<expected.size()); const auto& e=expected[j++];
                require(r.seq==e.seq && r.key==e.key && r.deleted==e.deleted && r.value==e.value);
            });
            require(j==expected.size());
        }
        for(size_t i=0;i<w.queries[g].size();++i) {
            auto q=w.queries[g][i];
            Hash got;
            start=Clock::now();
            s.read(q,h,[&](const Row& row){digest(got,row);});
            out.reads[g][h].push_back(nanos(start));
            sink=got.value;
            require(got.rows==w.oracle[g][i].size());
        }
    }
}

template<class A> static void after_trial(const Work& w,Samples& out) {
    requested=0; measure_alloc=true;
    auto s=std::make_unique<A>();
    measure_alloc=false; out.bytes=requested;
    trial(*s,w,out,std::is_same_v<A,PI> || std::is_same_v<A,PJ> || std::is_same_v<A,PS>);
}
static void run(unsigned phase) {
    auto w=workload(phase);
    std::array<Samples,COUNT> out;
    for(unsigned r=0;r<rounds;++r)for(unsigned j=0;j<COUNT;++j) {
        auto m=(r+j)%COUNT;
        switch(m) {
        case TC: case TI: { Tail t(m==TI); out[m].bytes=ts_store_bytes(t.p.get()); trial(t,w,out[m],true); break; }
        case AI0: after_trial<AI>(w,out[m]);break;
        case AJ0: after_trial<AJ>(w,out[m]);break;
        case PI0: after_trial<PI>(w,out[m]);break;
        case PJ0: after_trial<PJ>(w,out[m]);break;
        case PS0: after_trial<PS>(w,out[m]);break;
        }
    }
    for(unsigned m=0;m<COUNT;++m)for(unsigned g=0;g<5;++g)for(unsigned h=0;h<2;++h) {
        auto& v=out[m].reads[g][h];
        if(v.empty())continue;
        std::sort(v.begin(),v.end());
        std::printf("%s,%s,%s,%s,%zu,%zu,%.2f,%.2f,%llu,%llu\n",
            phase==2?"cluster-rewrite":phase?"after-compaction":"before-compaction",labels[m],groups[g],h?"hint":"numeric",
            w.oracle[g][0].size(),out[m].bytes,double(median(out[m].init))/capacity,
            double(median(out[m].write))/(w.trace.size()-capacity),
            (unsigned long long)v[v.size()/2],(unsigned long long)v[(v.size()*95+99)/100-1]);
    }
}
int main() {
    std::puts("phase,implementation,query,cursor,first_request_rows,allocated_bytes,initial_write_ns_each,rewrite_ns_each,read_p50_ns,read_p95_ns");
    run(0);run(1);run(2);
}
