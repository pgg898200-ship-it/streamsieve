# Tailstate and Afterkey

This benchmark compares the original Afterkey C++17 Index and Journal, their native bounded-page extension, an opt-in sparse-position Journal, and both Tailstate C99 engines. All use dense integer keys and 64-bit values. Each caller receives the latest value or deletion after its cursor in increasing revision order. The generic C++ containers also support other value types.

## Reproduce

From the Tailstate source tree, run the comparison against your local StreamSieve checkout with both commits fetched. The runner verifies the SHA-256 of every upstream header and stages both versions in temporary storage. It renames the candidate namespace and header guards to link both versions into one executable.

```sh
git clone https://github.com/pgg898200-ship-it/streamsieve.git /tmp/streamsieve
python3 bench/afterkey/run.py /tmp/streamsieve > afterkey-results.csv
```

The original Afterkey commit is `33590c650619a518e9f873e2825b6a5db47590e0`. The pinned candidate and output hashes are recorded below. The runner accepts `--tailstate /path/to/tailstate` when the benchmark directory is distributed separately. Use `--borg-input /path/to/normalized.txt` to compile the [Borg trace comparison](../real/) in the same pinned environment. The harness needs Git, Python 3, a C99 compiler, and a C++17 compiler. A compiler-specific `std::shuffle` means other standard libraries may generate different permutations from the same seed.

## Contract and workload

The pinned original exposes `since(cursor, callback)`, whose callback visits all matching rows. For the original 16-row page only, the benchmark stops by throwing a local sentinel and catching it outside `since`. The native extension accepts `since_page(cursor, optional_key, limit, callback)`. Both C stores use their public iterator and stop after 16 rows. Full reads use Afterkey's existing `since` or a Tailstate iterator to exhaustion. Cursor hints are tested for both libraries where supported. A hint identifies the last emitted row.

The optional Journal maintains a fixed two-level bitmap of live journal positions. When a cursor reaches a superseded position, it can jump to a nonempty word and use its first set bit to locate the next row. Writes update this metadata, and compaction rebuilds it.

Each run first fills all 65,536 slots in a shuffled key order, then rewrites every fourth key (including deletes). The before-compaction phase queries this state. The after-compaction phase adds 196,608 writes centered on 32 hot keys, with a new slow-changing key every 1,024 writes. Both phases test pages at adjacent initial revisions whose keys either retained their revisions or were overwritten. These page requests have 16 rows. The complete catch-up after compaction is approximately 32,768 writes behind with 64 rows for the nominal cursor. Before compaction the complete catch-up is approximately 4,096 writes behind.

A third phase then retires all keys in a contiguous quarter of the *original registration order* in one burst. Sampled cursors lie near the beginning of that interval. The packed journal contains a long run of obsolete positions before the next current row. This stress case demonstrates what happens when a deployment drains an entire registration cohort. Its frequency in a production fleet is unknown.

All seven implementations receive the same input. For every request, before timing, an independent final-state table sorted by revision checks each returned revision, key, value and tombstone. Timed calls consume all fields in an ordered hash. Seven trials rotate implementation order. Each query family uses 32 requests per trial. P50 and nearest-rank p95 are from 224 warmed calls. Build and rewrite figures are median time per write for fixed-length batches and exclude construction. The initial batch contains 65,536 writes. The rewrite batch length varies by phase. Requested memory includes the store and its buffers, excludes allocator metadata, and measures the C++ store through global allocation hooks active only during construction. Results measure local single-thread CPU wall time, including timer overhead and VM scheduling noise.

## Reference run

On an AMD EPYC 9V74 VM with Debian GCC/G++ 14.2.0, CPU affinity 2, the opt-in sparse Journal skipped long runs of obsolete positions. The ordinary page API also lets the caller stop after 16 rows without an exception. Each figure below is the p50 time for one warmed request; pre- and post-compaction full requests return 4,096 and 64 rows, respectively, at nominal lag.

| Numeric cursor | Original Afterkey Journal | Native Journal | Sparse Journal | Tailstate indexed |
| --- | ---: | ---: | ---: | ---: |
| 16 rows, overwritten anchor before compaction | 731 ns | 60 ns | 70 ns | 131 ns |
| 16 rows, overwritten anchor after compaction | 801 ns | 140 ns | 140 ns | 320 ns |
| 16 rows, cursor inside clustered retirements | 4,136 ns | 6,690 ns | 90 ns | 90 ns |
| Complete multirate catch-up after compaction | 9,094 ns | 4,727 ns | 261 ns | 230 ns |
| Complete 4,096-write catch-up before compaction | 6,750 ns | 6,710 ns | 6,780 ns | 27,230 ns |

The compact Tailstate store used 1,581,112 bytes, Afterkey Index 2,097,200 bytes, the ordinary Journal 2,621,528 bytes, the sparse Journal 2,638,216 bytes and Tailstate indexed 3,416,128 bytes. In the after-compaction phase, sparse Journal rewrites took 6.95 ns each versus 5.74 ns for native Journal. The original Afterkey Index returned the full multirate catch-up in 240 ns, so the 261 ns result for the sparse Journal should be interpreted alongside its page performance. The raw data includes hints and rewrite timings for all phases. [results.csv](results.csv)

The speedups for clustered retirement and sparse catch-up compare two settings of the same native Journal. The host and measured window affect absolute timings. The original Journal's page time includes exception unwinding. The bounded-count loop can be slower than the original traversal through many holes. An earlier run on the same host measured the original unbounded multirate Journal at 4,737 ns. Cross-run variation precludes a claim about improvements to that existing unlimited dense traversal.

The runner checks the SHA-256 of each original and candidate header before building.

Reference candidate `057fe3137ddacb7d6001fa7afbcca9725de3737c`. Frozen synthetic output SHA-256 `896b05703ec71429fd013a07a17c63f1d1b0eb652351e2db044971872aa11dfb`.
