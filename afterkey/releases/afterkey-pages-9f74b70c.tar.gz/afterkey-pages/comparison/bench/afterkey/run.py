"""Build and run the comparison against two committed StreamSieve revisions."""
import argparse
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ORIGINAL = '33590c650619a518e9f873e2825b6a5db47590e0'
CANDIDATE = '057fe3137ddacb7d6001fa7afbcca9725de3737c'

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('streamsieve', type=Path, help='existing StreamSieve clone containing both commits')
parser.add_argument('--candidate', default=CANDIDATE)
parser.add_argument('--borg-input', type=Path, help='run the Borg comparison on normalized borg.py output')
parser.add_argument('--tailstate', type=Path, default=HERE.parents[1], help='path to Tailstate source')
args = parser.parse_args()
with tempfile.TemporaryDirectory() as temp:
    tmp = Path(temp)
    for label, ref in [('old', ORIGINAL), ('new', args.candidate)]:
        dest = tmp / label
        dest.mkdir()
        for name in ('afterkey.hpp', 'afterkey_journal.hpp'):
            data = subprocess.check_output(['git', '-C', str(args.streamsieve), 'show', f'{ref}:afterkey/include/{name}'])
            (dest / name).write_bytes(data)
    subprocess.run([sys.executable, HERE/'prepare.py', tmp/'old', tmp/'new', tmp/'headers'], check=True)
    subprocess.run(['cc', '-std=c99', '-O3', '-DNDEBUG', '-I', args.tailstate/'include',
                    '-c', args.tailstate/'src/tailstate.c', '-o', tmp/'engine.o'], check=True)
    source = HERE.parent/'real'/'afterkey.cpp' if args.borg_input else HERE/'compare.cpp'
    subprocess.run(['c++', '-std=c++17', '-O3', '-DNDEBUG', '-I', args.tailstate/'include', '-I', tmp/'headers',
                    source, tmp/'engine.o', '-o', tmp/'compare'], check=True)
    if args.borg_input:
        with args.borg_input.open('rb') as trace:
            subprocess.run([tmp/'compare'], check=True, stdin=trace)
    else:
        subprocess.run([tmp/'compare'], check=True)
