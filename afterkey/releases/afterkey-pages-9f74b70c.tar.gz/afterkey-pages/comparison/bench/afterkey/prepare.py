"""Stage exact comparison headers, renaming only guards and namespace to allow co-linking."""
from hashlib import sha256
from pathlib import Path
import sys

original, candidate, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=True)
hashes = {
    'afterkey.hpp': (
        '82b64c5e70f5bb7418393341295554d54a39a965a954b454c0f4b0c8d9dd846b',
        '6517fdc34b15656c5f8b38fce5e32f00d3cae811b64aa4c110fdab94d50f039f'),
    'afterkey_journal.hpp': (
        'e9120c099e3722b89427e181d1e827e992b42a2389daa21a4329dd0afc269e38',
        'c12fa0dce6843d1dc98df6f0cb873f53e00a7a760a4a2c32c50108574eff80f1'),
}
for name, pair in hashes.items():
    for i, directory in enumerate((original, candidate)):
        raw = (directory / name).read_bytes()
        if sha256(raw).hexdigest() != pair[i]:
            raise ValueError(f'{directory / name}: expected pinned SHA-256 {pair[i]}')
        if i == 0:
            (out / name).write_bytes(raw)
        else:
            s = raw.decode().replace('AFTERKEY_', 'PAGED_AFTERKEY_')
            s = s.replace('namespace afterkey', 'namespace paged_afterkey')
            (out / ('paged_' + name)).write_text(s)
