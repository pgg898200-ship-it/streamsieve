# Afterkey bounded pages

This source kit contains the tested C++17 headers from StreamSieve commit `057fe3137ddacb7d6001fa7afbcca9725de3737c`. Both headers and the C++ test are Apache-2.0. Tailstate's C implementation and comparison harness in `comparison/` are MIT-licensed. Google retains its own license on the downloadable Borg trace.

Run a paged catch-up, including an overwritten cursor key and a deletion.

```sh
c++ -std=c++17 -O3 -Iinclude example.cpp -o demo && ./demo
c++ -std=c++17 -O3 tests/test_afterkey.cpp -o tests/run && ./tests/run
```

Use `afterkey::Journal<T>` for the default journal, or `afterkey::Journal<T, true>` when the cost of walking many superseded entries dominates. Each worker persists the acknowledged revision and optional key. Commit its cursor after applying the page. Keep a process-lifetime identifier at the transport boundary. Serialize writers and readers for each store. The bundled example uses one in-memory store and a single thread.

To reproduce comparisons with the actual old and new headers, clone the source repository and fetch the tested commit, then run from this extracted directory.

```sh
git clone https://github.com/pgg898200-ship-it/streamsieve.git streamsieve
git -C streamsieve fetch origin 057fe3137ddacb7d6001fa7afbcca9725de3737c
python3 comparison/bench/afterkey/run.py streamsieve
python3 comparison/bench/real/borg.py > borg.input
python3 comparison/bench/afterkey/run.py streamsieve --borg-input borg.input
```

See `comparison/bench/afterkey/README.md`, `comparison/bench/real/README.md`, and their CSVs for workloads, losses, hardware, and the exact trace hash. The comparison harness checks the fields of each returned row against an oracle.
