#include "afterkey_journal.hpp"
#include <cstdint>
#include <iostream>
#include <optional>

int main() {
    afterkey::Journal<std::uint64_t, true> state(4);
    auto last = state.put(0, 8);
    std::optional<std::uint32_t> hint{0};
    state.put(0, 7);
    state.put(1, 12);
    state.put(0, 6);
    state.erase(2);
    for (;;) {
        auto count = state.since_page(last, hint, 2, [&](auto seq, auto key, auto value) {
            std::cout << seq << " key=" << key;
            if (value) std::cout << " slots=" << *value;
            else std::cout << " deleted";
            std::cout << "\n";
            last = seq;
            hint = key;
        });
        if (count == 0) break;
    }
}
